let currentInput = null;
let container = null;

// Shortcut to toggle (Ctrl + Shift + I)
document.addEventListener("keydown", (e) => {
  if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "i") {
    if (!container) createFloatingBox();
    else toggleFloatingBox();
  }
});

// Watch focus events
document.addEventListener("focusin", (e) => {
  if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") {
    currentInput = e.target;
    if (!container) createFloatingBox();

    const inputBox = document.getElementById("floating-box-input");
    inputBox.value = currentInput.value;
    container.style.display = "block";
    inputBox.focus();
  }
});

// Create the floating box
function createFloatingBox() {
  container = document.createElement("div");
  container.id = "floating-input-container";

  Object.assign(container.style, {
    position: "fixed",
    top: "10%",
    left: "50%",
    transform: "translateX(-50%)",
    zIndex: 9999,
    padding: "16px",
    borderRadius: "12px",
    boxShadow: "0 8px 24px rgba(0,0,0,0.2)",
    background: "#fff",
    color: "#000",
    minWidth: "300px",
    fontFamily: "Arial",
    display: "block"
  });

  // ❌ Close Button
  const closeBtn = document.createElement("span");
  closeBtn.textContent = "❌";
  Object.assign(closeBtn.style, {
    float: "right",
    cursor: "pointer",
    fontSize: "18px",
    marginBottom: "8px"
  });
  closeBtn.onclick = () => (container.style.display = "none");
  container.appendChild(closeBtn);

  // 🧠 Input Box
  const input = document.createElement("input");
  input.id = "floating-box-input";
  Object.assign(input.style, {
    width: "100%",
    fontSize: "16px",
    padding: "10px",
    borderRadius: "8px",
    border: "1px solid #ccc",
    outline: "none"
  });

  // Sync input (⚠️ Includes React/Vue support)
  input.addEventListener("input", () => {
    if (!currentInput) return;

    // For regular inputs
    currentInput.value = input.value;

    // For React/Vue inputs — use the native setter
    const nativeSetter = Object.getOwnPropertyDescriptor(
      currentInput.__proto__,
      "value"
    ).set;
    nativeSetter.call(currentInput, input.value);

    // Dispatch proper input events to notify JS frameworks
    currentInput.dispatchEvent(new Event("input", { bubbles: true }));
    currentInput.dispatchEvent(new Event("change", { bubbles: true }));
  });

  // ESC key closes box
  input.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      container.style.display = "none";
    }
  });

  container.appendChild(input);
  document.body.appendChild(container);
}

// Toggle floating box visibility
function toggleFloatingBox() {
  if (!container) return;

  const inputBox = document.getElementById("floating-box-input");
  const isVisible = container.style.display !== "none";
  container.style.display = isVisible ? "none" : "block";

  if (currentInput && inputBox) {
    inputBox.value = currentInput.value;
    inputBox.focus();
  }
}



